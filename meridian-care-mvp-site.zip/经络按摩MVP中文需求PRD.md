# AI 经络养护 MVP 中文需求 PRD

## 1. 产品定位

AI 经络养护是一款面向西方用户的轻量自助按摩养生 App。用户通过 Apple 登录后先完成 AI 计划定制，在生成计划前进入订阅墙；订阅后生成每日经络按摩计划，并通过手部经络点示意、步骤高亮和倒计时完成打卡。

## 2. MVP 核心目标

- 将产品主线收束为“每日自助按摩养生”。
- 让用户在 3 步内生成个性化按摩计划。
- 用简洁、温暖、偏 iOS 原生的界面降低理解成本。
- 保留订阅、每日打卡、计划重新定制、多语言设置。

## 3. 用户流程

1. 用户进入 App。
2. 使用 Apple 登录。
3. 进入计划定制。
4. 第一步：选择最想改善的目标。
5. 第二步：确认养生目标、建议按摩部位和每日投入时间。
6. 第三步：填写 AI 补充反馈，或直接跳过。
7. 用户点击提交或跳过后，弹出订阅墙。
8. 用户完成订阅。
9. AI 生成 7 日按摩计划。
10. 用户进入 App 时出现通知授权提示，可允许或稍后设置。
11. 进入首页，查看今日按摩计划。
12. 可在首页点击“重新定制”重新生成计划。
13. 进入按摩打卡页，点击大按钮开始打卡。
14. 开始后，大按钮和开始表现区域消失，由按摩引导流程替代。
15. 按步骤完成每日按摩打卡。

## 4. 订阅规则

- 月度订阅：9.90 美元/月。
- 年度订阅：49.90 美元/年。
- 年度订阅提供 3 天免费试用。
- 未订阅用户可浏览界面，但无法使用完整 AI 计划、步骤引导、打卡小结等核心功能。

## 5. 订阅权益

- AI 个性化按摩计划。
- 每日手部经络点按摩引导。
- 首页练习进度与连续打卡小结。
- 首页练习进度与连续打卡小结。

## 6. 信息架构

- 首页：个人计划、今日按摩练习、本周小结。
- 打卡：开始打卡按钮、手部经络点示意、当前步骤高亮、倒计时、完成打卡。
- 养生内容模块暂时隐藏，MVP 底部只保留“首页”和“打卡”两个模块。
- 个人中心：订阅情况、语言设置、关于我们、服务条款与隐私协议、账号注销、退出登录。

账号注销：

- 入口放在个人中心设置列表中。
- 用户点击后展示二次确认弹窗。
- 弹窗说明账号、个人计划、打卡记录和偏好设置将被永久删除。
- 提醒用户有效订阅仍需通过 App Store 管理。
- 用户可取消，或确认注销并回到登录页。

## 7. 计划定制

第一步：选择改善目标。

- Sleep & Relaxation
- Fatigue Relief
- Digestive Care
- Energy & Circulation
- Liver Care
- Weight & Fat Loss

第二步：显示养生目标、建议按摩部位和每日时间。

- 默认时间：10 分钟。
- 可选时间：5 分钟、10 分钟、15 分钟。
- 不同目标对应不同建议部位，例如睡眠放松建议头颈，肝脏护理建议足部。

第三步：AI 补充反馈。

- 用户可描述睡眠、压力、酸痛、精力状态等。
- 若选择提交反馈，输入框为空时不可生成计划。
- 用户也可直接跳过。

## 8. 每日按摩打卡

MVP 只保留按摩养生一条主线。

- 展示今日按摩名称。
- 展示拟人化手部示意。
- 标注手部经络点，并在当前步骤高亮需要按摩的位置。
- 展示当前步骤倒计时、步骤序号和简短说明。
- 用户点击“开始打卡”后进入按摩引导。
- 倒计时默认自动运行，用户点击倒计时圆环可暂停或继续。
- 每一步的倒计时时长根据 AI 计划配置。
- 用户可点击步骤切换按摩部位，手部高亮点、倒计时和说明同步变化。
- 用户点击“完成打卡”完成今日练习。
- 完成后首页同步更新今日状态与本周小结。

## 9. 暂缓功能

- 调理趋势暂时不在 MVP 首页展示。
- 体检报告上传、相册授权、AI 指标分析暂时作为后续版本能力保留。

## 10. 周期完成状态

当用户完成一个周期的打卡计划后，首页展示周期完成状态。

- 提示用户“打卡计划已完美实施”。
- 提供“继续原计划打卡”入口，用户可保持当前计划继续执行。
- 提供“开始进阶打卡计划”入口，提示将由 AI 分析用户完成情况并制定下一周期进阶计划。
- 用户进入进阶计划前，需要先回答与上一周期目标相关的复盘问题。
- 例如上一周期目标为睡眠放松时，询问睡眠质量是否改善、入睡是否更快、夜间醒来是否减少、醒后精神是否更好。
- AI 根据上一周期打卡结果和用户复盘反馈，直接生成下一周期进阶打卡计划。
- 进阶计划不再让用户重新选择每日时间，也不再进入 AI 补充对话页。
- 用户点击生成后直接进入打卡模块，开始执行进阶打卡。

## 11. 多语言

- 设置中支持 English 与中文切换。
- 切换语言不应重置订阅状态、当前页面、已选目标、已选图片或打卡状态。
- MVP 默认面向西方用户，英文文案优先简洁直接。

## 12. 埋点需求

核心埋点目标：

- 追踪首次计划定制完成率。
- 追踪订阅墙曝光、关闭、订阅点击和订阅成功。
- 追踪未订阅浏览态下，用户从首页或打卡页再次点击订阅的情况。
- 追踪每日打卡开始、暂停、继续和完成。
- 追踪周期完成后，用户选择继续原计划或进阶计划的比例。

建议事件：

- app_open
- apple_sign_in_success
- plan_setup_start
- plan_goal_select
- plan_time_select
- ai_feedback_submit
- ai_feedback_skip
- paywall_show
- paywall_close
- subscription_plan_select
- subscription_cta_click
- subscription_success
- restore_purchase_click
- notification_allow_click
- notification_later_click
- home_view
- home_locked_cta_click
- checkin_view
- checkin_start_click
- timer_pause_click
- timer_resume_click
- checkin_complete_success
- cycle_complete_show
- continue_original_plan_click
- advanced_plan_click
- advanced_review_answer_select
- advanced_plan_generate_click
- settings_open
- language_change
- delete_account_click
- delete_account_confirm

公共参数：

- user_id
- session_id
- app_version
- language
- subscription_status
- entry_source
- timestamp

注意事项：

- 不采集 AI 输入的明文内容，只记录是否输入和文本长度。
- 健康相关反馈只做枚举化统计。
- 订阅失败记录标准错误码，不记录支付账号信息。

## 13. ASO 优化建议

ASO 主轴调整：

- 第一优先级：meridian
- 第二优先级：acupressure
- 第三优先级：TCM

英文关键词方向：

- meridian
- meridian massage
- acupressure
- self massage
- hand massage
- wellness
- stress relief
- sleep
- relaxation
- guided routine
- habit
- check in
- TCM

英文标题候选：

- Meridian Care
- Meridian Massage
- Meridian Self Massage
- Meridian Acupressure
- Meridian Care: Acupressure

推荐标题：

- Meridian Care

英文副标题候选：

- Guided acupressure plan
- Daily self-massage guide
- AI meridian massage plan
- Gentle meridian check-ins
- TCM self-care routines

截图卖点建议：

- AI builds your meridian plan
- Follow simple guided routines
- Track your weekly massage progress
- Follow highlighted acupressure points

中文关键词方向：

- 经络按摩
- 经络养护
- 穴位按摩
- 自助按摩
- 手部按摩
- 养生打卡
- AI 养生计划
- 睡眠放松
- 肩颈放松
- TCM
- 中医按摩

## 14. MVP 暂不包含

- 泡茶养生打卡。
- 茶饮配方与泡茶步骤。
- 双线任务切换。
- 医疗诊断、处方建议或疾病治疗承诺。
