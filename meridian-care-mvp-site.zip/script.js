const app = document.querySelector(".iphone");
const tabButtons = document.querySelectorAll(".ios-tabbar button");
const navButtons = document.querySelectorAll("[data-target]");
const backButtons = document.querySelectorAll("[data-back]");
const closePaywallButton = document.querySelector("[data-close-paywall]");
const planOptionButtons = document.querySelectorAll("[data-plan-option]");
const planNote = document.querySelector("[data-plan-note]");
const subscribeCta = document.querySelector("[data-subscribe-cta]");
const checkButtons = document.querySelectorAll("[data-check]");
const taskButtons = document.querySelectorAll("[data-task-target]");
const taskPanels = document.querySelectorAll("[data-task-panel]");
const choiceGroups = document.querySelectorAll(".feedback-grid, .body-grid, .time-options, .advanced-grid");
const aiFillButton = document.querySelector("[data-ai-fill]");
const feedbackSubmitButton = document.querySelector("[data-require-feedback]");
const focusTitle = document.querySelector("[data-focus-title]");
const focusCopy = document.querySelector("[data-focus-copy]");
const massageTarget = document.querySelector("[data-massage-target]");
const photoPermissionButton = document.querySelector("[data-photo-permission]");
const permissionModal = document.querySelector("[data-permission-modal]");
const permissionCloseButton = document.querySelector("[data-permission-close]");
const photoButtons = document.querySelectorAll("[data-photo-select]");
const confirmPhotoButton = document.querySelector("[data-confirm-photo]");
const uploadReportButton = document.querySelector("[data-upload-report]");
const notificationOpenButton = document.querySelector("[data-open-notification]");
const notificationAllowButton = document.querySelector("[data-notification-allow]");
const notificationLaterButton = document.querySelector("[data-notification-later]");
const profileOpenButton = document.querySelector("[data-profile-open]");
const profileCloseButtons = document.querySelectorAll("[data-profile-close]");
const deleteAccountOpenButton = document.querySelector("[data-delete-account-open]");
const deleteAccountCloseButtons = document.querySelectorAll("[data-delete-account-close]");
const deleteAccountConfirmButton = document.querySelector("[data-delete-account-confirm]");
const languageButtons = document.querySelectorAll("[data-language]");
const languageLabel = document.querySelector("[data-language-label]");
const meridianStepButtons = document.querySelectorAll("[data-meridian-step]");
const meridianPoints = document.querySelectorAll("[data-point]");
const stepTime = document.querySelector("[data-step-time]");
const stepCount = document.querySelector("[data-step-count]");
const stepCopy = document.querySelector("[data-step-copy]");
const startRoutineButton = document.querySelector("[data-start-routine]");
const timerToggleButton = document.querySelector("[data-timer-toggle]");
const completeRoutineButton = document.querySelector("[data-complete-routine]");
const screens = document.querySelectorAll(".screen");

const purposeFocusByLanguage = {
  en: {
    sleep: ["Sleep & Relaxation", "Gentle head and neck release for evening relaxation.", "Head & Neck"],
    fatigue: ["Fatigue Relief", "Shoulder and neck release to reset daily tension.", "Shoulder & Neck"],
    stomach: ["Digestive Care", "Gentle abdominal meridian care for daily balance.", "Abdomen"],
    blood: ["Energy & Circulation", "Hands and feet massage to support warmth and circulation.", "Hands & Feet"],
    liver: ["Liver", "Liver care plan with foot and palm meridian points.", "Feet"],
    weight: ["Weight & Fat Loss", "Abdominal and leg massage for a light daily reset.", "Abdomen"],
    default: ["Sleep & Relaxation", "Gentle head and neck release for evening relaxation.", "Head & Neck"],
  },
  zh: {
    sleep: ["睡眠放松", "通过头颈轻柔放松，帮助进入晚间休息状态。", "头颈"],
    fatigue: ["缓解疲劳", "通过肩颈放松，缓解日常紧绷感。", "肩颈"],
    stomach: ["脾胃调养", "通过腹部经络轻柔护理，支持日常平衡。", "腹部"],
    blood: ["血气调整", "通过手足按摩，辅助温暖与循环。", "手足"],
    liver: ["肝脏护理", "通过足部与掌心经络点进行肝脏护理。", "足部"],
    weight: ["减重减脂", "通过腹部与腿部按摩，完成轻量日常调理。", "腹部"],
    default: ["睡眠放松", "通过头颈轻柔放松，帮助进入晚间休息状态。", "头颈"],
  },
};

let currentLanguage = "en";
let purposeFocus = purposeFocusByLanguage.en;
let routineTimer = null;
let activeStepIndex = 0;
let remainingSeconds = 60;
let routinePaused = false;
let currentScreen = document.querySelector(".screen.active")?.id || "login";
const screenHistory = [];

const enToZh = {
  "Meridian Care MVP": "经络养护 MVP",
  "Sign in with Apple": "使用 Apple 登录",
  "Set your plan first. Membership appears when AI is ready to generate it.": "先完成计划设定，AI 准备生成方案时再开通会员。",
  "Close": "关闭",
  "Membership": "会员方案",
  "Subscribe to generate your plan and unlock daily guided massage.": "开通后生成专属计划，并解锁每日引导按摩。",
  "Guided meridian massage": "经络按摩指导",
  "Follow GIF demos designed for self-care at home.": "跟随动作演示，在家完成轻量自助护理。",
  "Monthly": "月度会员",
  "$9.90/month": "$9.90/月",
  "Annual": "年度会员",
  "$49.90/year": "$49.90/年",
  "$4.16/month": "$4.16/月",
  "$49.90 billed yearly": "每年 $49.90",
  "3-day free trial": "3 天免费试用",
  "Start membership": "开通会员",
  "Start 3-day free trial": "立即免费体验 3 天",
  "Annual plan includes a 3-day free trial, then renews automatically.": "年度方案含 3 天免费试用，试用结束后自动续订。",
  "Monthly plan renews automatically at $9.90/month.": "月度方案按 $9.90/月自动续订。",
  "Restore Purchase": "恢复购买",
  "Terms": "用户协议",
  "Build a daily routine around your goal, time, and body focus.": "围绕你的目标、时间和身体重点制定每日练习。",
  "Follow guided demos designed for self-care at home.": "跟随动作引导，在家完成轻量自助护理。",
  "Privacy Policy": "隐私条款",
  "Plan Setup · 1/3": "计划定制 · 1/3",
  "What would you like to improve most?": "你最想改善什么？",
  "Choose one primary goal": "选择一个最重要的目标",
  "Sleep & Relaxation": "睡眠放松",
  "Fatigue Relief": "缓解疲劳",
  "Digestive Care": "脾胃调养",
  "Energy & Circulation": "血气调整",
  "Liver Care": "肝脏护理",
  "Weight & Fat Loss": "减重减脂",
  "Next": "下一步",
  "Plan Setup · 2/3": "计划定制 · 2/3",
  "Wellness Settings": "计划设置",
  "Wellness Goal": "养生目标",
  "Suggested massage area": "建议按摩部位",
  "Head & Neck": "头颈",
  "Daily time": "每天花费时间",
  "Default 10 minutes": "默认 10 分钟",
  "5 min": "5 分钟",
  "10 min": "10 分钟",
  "15 min": "15 分钟",
  "Plan Setup · 3/3": "计划定制 · 3/3",
  "AI Details": "AI 补充",
  "Optional": "可选",
  "Tell AI more about your situation": "补充你的当前状态",
  "Example: poor sleep, low appetite, afternoon fatigue, or tight shoulders.": "例如：最近熬夜、胃口差、下午疲惫、肩颈紧。",
  "Describe your situation...": "输入你的情况...",
  "AI will analyze your feedback and create a wellness plan that better fits your current condition.": "AI 会结合你的反馈，生成更贴合当前状态的养护计划。",
  "Submit feedback": "提交反馈",
  "Skip": "直接跳过",
  "AI Generated": "AI 计划已生成",
  "Today’s Plan": "今日计划",
  "Liver Ease": "疏肝放松",
  "Massage": "按摩",
  "Shoulder & Neck Relief": "肩颈放松",
  "Start using": "进入 App",
  "Allow": "允许",
  "Set Up Later": "稍后设置",
  "Home": "首页",
  "Not subscribed": "未订阅",
  "View subscription": "查看会员方案",
  "Personal Plan": "个人计划",
  "Start check-in": "开始打卡",
  "12 min": "12 分钟",
  "Weekly Wellness Summary": "本周打卡小结",
  "Cycle Complete": "周期已完成",
  "Your plan was completed perfectly": "你的打卡计划已完美实施",
  "You completed this check-in cycle on schedule. Keep the same plan or let AI analyze your progress and create an advanced routine.": "你已按计划完成本周期打卡。可以继续原计划，也可以让 AI 分析进度并制定进阶打卡计划。",
  "Continue original plan": "继续原计划打卡",
  "Start advanced plan": "开始进阶打卡计划",
  "AI will analyze and customize the next cycle": "AI 将分析结果并制定下一周期计划",
  "Review your last cycle": "复盘上一周期",
  "Previous goal": "上一周期目标",
  "AI will use your check-in results and these answers to create a more advanced plan.": "AI 会结合打卡结果和本次反馈，为你生成进阶计划。",
  "Has your sleep quality improved?": "你的睡眠质量是否有改善？",
  "Choose one": "选择一项",
  "Clearly improved": "明显改善",
  "Slightly improved": "略有改善",
  "No clear change": "暂无明显变化",
  "What changed most?": "哪方面变化最明显？",
  "Fall asleep faster": "入睡更快",
  "Wake up less often": "夜间醒来减少",
  "Feel better in the morning": "醒后精神更好",
  "Generate and start check-in": "生成并进入打卡",
  "AI Review · Direct to check-in": "AI 复盘 · 直接进入打卡",
  "7 days": "7 日",
  "Streak": "连续",
  "5 days": "5 天",
  "Done": "已完成",
  "7 items": "7 项",
  "5 routines": "5 次",
  "Focus": "重点",
  "Liver": "肝脏",
  "Wellness Trend": "调理趋势",
  "Needs data": "需资料",
  "Upload a pre-care health report screenshot before AI can generate trend comparisons.": "上传开始调理前的体检报告截图后，AI 才会生成趋势对比。",
  "AI is analyzing your health report. Trends such as transaminase indicators will appear after analysis.": "AI 正在分析你的体检报告，完成后将展示转氨酶等指标趋势。",
  "Upload health report screenshot": "上传体检报告截图",
  "Focus on ALT / AST and other transaminase values": "重点查看 ALT / AST 等转氨酶数值",
  "AI analyzing": "AI 分析中",
  "Add baseline data": "添加基准资料",
  "Baseline Data": "基准资料",
  "Upload Report": "上传资料",
  "Back": "返回",
  "Upload a pre-care health report screenshot": "上传开始调理前的体检报告截图",
  "AI will prioritize ALT / AST and other transaminase values for future trend comparison.": "AI 会优先识别 ALT / AST 等转氨酶数值，用于后续趋势对比。",
  "Choose one photo from Library": "从相册选择一张照片",
  "Selected": "已选择",
  "health-report.jpg": "体检报告截图.jpg",
  "Single photo · ready to upload": "单张照片 · 等待上传",
  "Upload and analyze": "上传并分析",
  "Used to select a health report screenshot so AI can create your pre-care baseline.": "用于选择体检报告截图，帮助 AI 建立调理前的基准资料。",
  "Allow Full Access": "允许访问所有照片",
  "Don’t Allow": "不允许",
  "Photos": "照片",
  "Choose Photo": "选择照片",
  "Cancel": "取消",
  "Report": "报告",
  "Record": "记录",
  "Screenshot": "截图",
  "Use This Photo": "选择这张照片",
  "Check-in": "打卡",
  "Retune Plan": "重新定制计划",
  "Locked": "未解锁",
  "Subscribe to view full check-in": "订阅后查看完整打卡",
  "Start membership": "开启会员",
  "Shoulder-Neck Meridian": "肩颈经络",
  "GIF guide · can check in alone": "GIF 引导 · 可单独打卡",
  "Can complete alone": "可单独完成",
  "Massage Check-in": "按摩打卡",
  "Shoulder-Neck Meridian Massage": "肩颈经络按摩",
  "Follow the GIF gently. Stop immediately if you feel discomfort.": "跟随 GIF 轻柔按揉。如有不适，请立即停止。",
  "Step 2 / 6": "第 2 / 6 步",
  "Complete massage check-in": "完成按摩打卡",
  "Massage checked in": "按摩已打卡",
  "Today’s Progress": "今日进度",
  "Content & Consultation": "内容与咨询",
  "Wellness": "养生",
  "Subscribe to view wellness content": "订阅后查看养生内容",
  "Today’s Pick": "今日推荐",
  "Wellness Content": "养生内容",
  "Featured": "精选",
  "Shoulder-neck relief for desk workers": "久坐人群的肩颈放松",
  "3 self-massage points after work": "3 个适合下班后的自助按摩点",
  "AI Consultation": "AI 咨询",
  "Describe how you feel today": "描述你今天的状态",
  "Start consultation": "开始咨询",
  "Profile": "设置",
  "Subscription": "订阅情况",
  "Annual member · trial active": "年度会员 · 试用中",
  "Renew or manage": "续订 / 管理",
  "Language": "语言",
  "English": "英文",
  "EN": "EN",
  "V1.0.0": "V1.0.0",
  "AI Meridian Care": "AI 经络养护",
  "Personalized massage care in minutes": "几分钟完成专属按摩养护",
  "Get a simple daily self-massage plan based on your goal, body focus, and routine.": "根据你的目标、身体重点和日常节奏，生成简单的每日自助按摩计划。",
  "Get your AI massage plan": "生成你的 AI 按摩计划",
  "Personalized massage plan": "个性化按摩计划",
  "Build a daily routine around your goal, time, and body focus.": "围绕你的目标、时间和身体重点制定每日练习。",
  "Progress insights": "进度记录",
  "Track your routine, streak, and weekly progress in one place.": "在首页查看练习、连续完成和本周进度。",
  "Retune Plan": "重新定制",
  "Hand guide · 4 steps": "手部引导 · 4 步",
  "Guided massage steps and highlighted meridian points will appear here.": "这里会显示按摩步骤和高亮经络点。",
  "Today’s Check-in": "今日打卡",
  "4 guided steps · tap the timer anytime to pause.": "4 个引导步骤 · 点击计时器可暂停。",
  "Start check-in": "开始打卡",
  "Gentle head and neck release for evening relaxation.": "通过头颈轻柔放松，帮助进入晚间休息状态。",
  "Shoulder and neck release to reset daily tension.": "通过肩颈放松，缓解日常紧绷感。",
  "Gentle abdominal meridian care for daily balance.": "通过腹部经络轻柔护理，支持日常平衡。",
  "Hands and feet massage to support warmth and circulation.": "通过手足按摩，辅助温暖与循环。",
  "Abdominal and leg massage for a light daily reset.": "通过腹部与腿部按摩，完成轻量日常调理。",
  "7-Day Massage Plan": "7 日按摩计划",
  "Foot reflex massage and shoulder-neck release, about 10 min daily.": "足部反射区按摩 + 肩颈放松，每天约 10 分钟。",
  "Today": "今日",
  "Shoulder-Neck Release": "肩颈放松",
  "Focus": "重点",
  "Feet + Neck": "足部 + 颈部",
  "AI suggested areas": "AI 建议部位",
  "“Meridian Care” Would Like to Send You Notifications": "“经络养护”想给你发送通知",
  "Notifications may include daily massage reminders and plan progress updates.": "用于提醒每日按摩练习和计划进度。",
  "Subscribe to unlock your plan": "开通后解锁你的计划",
  "You can browse first. Guided routines, AI plans, and weekly summaries unlock after subscription.": "你可以先浏览界面。开通后解锁动作引导、AI 计划和本周小结。",
  "Subscribe to start daily check-ins": "订阅 App，立即开始每日打卡",
  "Your plan is ready. Subscribe to unlock guided massage and begin today’s check-in.": "你的计划已准备好。订阅后即可解锁按摩引导，并开始今日打卡。",
  "Subscribe now": "立即订阅",
  "Complete today’s 10-minute guided massage.": "完成今天 10 分钟引导按摩。",
  "Start routine": "开始打卡",
  "Today’s Routine": "今日练习",
  "10 min": "10 分钟",
  "Your evening routine is most consistent. Keep today’s session light and steady.": "你的晚间练习最稳定。今天保持轻柔、稳定即可。",
  "“Meridian Care” Would Like to Access Your Photos": "“经络养护”想访问你的照片",
  "Lab": "化验",
  "Daily Routine": "每日练习",
  "Subscribe to view your routine": "开通后查看你的练习",
  "No active plan": "暂无可用计划",
  "Your check-in is waiting": "你的打卡内容待解锁",
  "Subscribe to unlock the hand guide, timer, and highlighted meridian points.": "订阅后解锁手部引导、倒计时和经络点高亮。",
  "Subscribe to check in": "订阅并开始打卡",
  "Guided massage steps and GIF demos will appear here.": "这里会显示按摩步骤和 GIF 演示。",
  "Guided Routine": "按摩引导",
  "Hand Meridian Reset": "手部经络放松",
  "01:00": "01:00",
  "01:30": "01:30",
  "Step 1 / 4": "第 1 / 4 步",
  "Step 2 / 4": "第 2 / 4 步",
  "Step 3 / 4": "第 3 / 4 步",
  "Step 4 / 4": "第 4 / 4 步",
  "Press the thumb base with slow circles.": "在拇指根部缓慢画圈按揉。",
  "Glide along the center palm line.": "沿掌心中线轻柔推按。",
  "Hold the wrist point and breathe slowly.": "按住腕部点位并缓慢呼吸。",
  "Massage each fingertip with light pressure.": "用轻压力揉按每个指尖。",
  "Thumb base": "拇指根部",
  "Palm line": "掌心线",
  "Wrist point": "腕部点位",
  "Fingertips": "指尖",
  "Complete check-in": "完成本次打卡",
  "Check-in complete": "打卡完成",
  "1 routine": "1 组练习",
  "Massage education and AI consultation will appear here.": "这里会提供按摩知识和 AI 咨询入口。",
  "No content yet": "暂无内容",
  "Wellness content is locked": "养生内容待解锁",
  "Subscribe to unlock massage education and AI suggestions.": "订阅后解锁按摩知识和 AI 建议。",
  "Release Tension Gently": "轻柔释放紧绷",
  "Start with light pressure around the neck, shoulders, and feet.": "从颈部、肩部和足部的轻压力开始。",
  "Neck tension after long desk hours": "久坐后的颈部紧绷",
  "Simple pressure points to relax tight areas": "用简单按压点放松紧绷部位",
  "N": "颈",
  "Share sleep, stress, soreness, or energy level, and AI will suggest a massage routine.": "描述睡眠、压力、酸痛或精力状态，AI 会建议对应按摩练习。",
  "Meridian Care User": "经络养护用户",
  "AI massage plans, guided routines, and weekly summaries are unlocked.": "已解锁 AI 按摩计划、动作引导和本周小结。",
  "Subscribe to generate your personal massage plan.": "开通后生成你的专属按摩计划。",
  "M": "按",
  "About Us": "关于我们",
  "View": "查看",
  "Delete Account": "注销账号",
  "Permanent": "永久删除",
  "Account Deletion": "账号注销",
  "Delete your account?": "确认注销账号？",
  "This will permanently delete your account, personal plan, check-in history, and saved preferences. Active subscriptions should still be managed through the App Store.": "这将永久删除你的账号、个人计划、打卡记录和偏好设置。有效订阅仍需前往 App Store 管理。",
  "Cancel": "取消",
  "Delete account": "注销账号",
  "Log Out": "退出登录",
  "Back to login": "返回登录",
};

const zhToEn = Object.fromEntries(Object.entries(enToZh).map(([en, zh]) => [zh, en]));

const appScreens = new Set(["today", "practice"]);
const onboardingScreens = new Set([
  "login",
  "subscribe",
  "plan-step-1",
  "plan-step-2",
  "plan-step-3",
  "plan-result",
  "advanced-review",
]);

function setMode(mode) {
  app.classList.remove("is-subscribed", "is-unsubscribed");
  app.classList.add(mode === "subscribed" ? "is-subscribed" : "is-unsubscribed");
}

function translateTextNodes(targetLanguage) {
  const dictionary = targetLanguage === "zh" ? enToZh : zhToEn;
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  const textNodes = [];

  while (walker.nextNode()) {
    textNodes.push(walker.currentNode);
  }

  textNodes.forEach((node) => {
    const text = node.nodeValue.trim();

    if (!text || !dictionary[text]) {
      return;
    }

    node.nodeValue = node.nodeValue.replace(text, dictionary[text]);
  });
}

function refreshSelectedFocus() {
  const selectedPurpose = document.querySelector(".feedback-chip.active");
  const purpose = selectedPurpose?.dataset.purpose || "default";
  const [title, copy, massage] = purposeFocus[purpose] || purposeFocus.default;

  focusTitle.textContent = title;
  focusCopy.textContent = copy;
  massageTarget.textContent = massage;
}

function setLanguage(language) {
  if (language === currentLanguage) {
    return;
  }

  translateTextNodes(language);
  currentLanguage = language;
  purposeFocus = purposeFocusByLanguage[language];
  document.documentElement.lang = language === "zh" ? "zh-CN" : "en";
  languageLabel.textContent = language === "zh" ? "中文" : "English";

  languageButtons.forEach((button) => {
    button.classList.toggle("active", button.dataset.language === language);
  });

  refreshSelectedFocus();
}

function closeProfile() {
  app.classList.remove("profile-open");
}

function closeDeleteAccount() {
  app.classList.remove("delete-account-open");
}

function closePermission() {
  app.classList.remove("permission-open", "notification-open", "delete-account-open");
}

function finishNotificationPrompt(allowed) {
  app.classList.toggle("notification-enabled", allowed);
  setMode("subscribed");
  showScreen("today");
}

function showScreen(target, options = {}) {
  const shouldPush = options.push !== false;

  closeProfile();
  closePermission();
  resetRoutine();
  if (shouldPush && currentScreen && currentScreen !== target) {
    screenHistory.push(currentScreen);
  }
  screens.forEach((screen) => screen.classList.remove("active"));
  document.getElementById(target).classList.add("active");
  currentScreen = target;

  app.classList.toggle("onboarding-mode", onboardingScreens.has(target) && !appScreens.has(target));

  tabButtons.forEach((item) => {
    item.classList.toggle("active", item.dataset.target === target);
  });
}

function goBack() {
  const fallbackByScreen = {
    subscribe: app.classList.contains("is-subscribed") ? "today" : "plan-step-3",
    "plan-step-1": app.classList.contains("is-subscribed") ? "today" : "login",
    "plan-step-2": "plan-step-1",
    "plan-step-3": "plan-step-2",
    "advanced-review": "today",
    "report-upload": "today",
    "photo-picker": "report-upload",
  };
  let previous = screenHistory.pop();

  while (previous === currentScreen) {
    previous = screenHistory.pop();
  }

  showScreen(previous || fallbackByScreen[currentScreen] || "today", { push: false });
}

function closePaywall() {
  if (!app.classList.contains("is-subscribed")) {
    setMode("unsubscribed");
    showScreen("today");
    return;
  }

  goBack();
}

function setSelectedPlan(plan) {
  const notes = {
    en: {
      annual: "Annual plan includes a 3-day free trial, then renews automatically.",
      monthly: "Monthly plan renews automatically at $9.90/month.",
    },
    zh: {
      annual: "年度方案含 3 天免费试用，试用结束后自动续订。",
      monthly: "月度方案按 $9.90/月自动续订。",
    },
  };
  const ctaLabels = {
    en: {
      annual: "Start 3-day free trial",
      monthly: "Start membership",
    },
    zh: {
      annual: "立即免费体验 3 天",
      monthly: "开通会员",
    },
  };

  planOptionButtons.forEach((button) => {
    button.classList.toggle("selected", button.dataset.planOption === plan);
  });

  planNote.textContent = notes[currentLanguage][plan];
  subscribeCta.textContent = ctaLabels[currentLanguage][plan];
}

function formatTime(seconds) {
  const minutes = Math.floor(seconds / 60).toString().padStart(2, "0");
  const rest = (seconds % 60).toString().padStart(2, "0");
  return `${minutes}:${rest}`;
}

function stopRoutineTimer() {
  window.clearInterval(routineTimer);
  routineTimer = null;
}

function setMeridianStep(index, shouldRun = false) {
  const button = meridianStepButtons[index];

  if (!button) {
    stopRoutineTimer();
    return;
  }

  activeStepIndex = index;
  remainingSeconds = Number(button.dataset.seconds || 60);

  meridianStepButtons.forEach((item) => item.classList.toggle("active", item === button));
  meridianPoints.forEach((point) => point.classList.toggle("active", point.dataset.point === button.dataset.meridianStep));

  stepTime.textContent = formatTime(remainingSeconds);
  stepCount.textContent =
    currentLanguage === "zh"
      ? `第 ${button.dataset.meridianStep} / ${meridianStepButtons.length} 步`
      : `Step ${button.dataset.meridianStep} / ${meridianStepButtons.length}`;
  stepCopy.textContent = currentLanguage === "zh" ? enToZh[button.dataset.copy] : button.dataset.copy;

  if (shouldRun) {
    startRoutineTimer();
  }
}

function tickRoutine() {
  if (routinePaused) {
    return;
  }

  remainingSeconds = Math.max(remainingSeconds - 1, 0);
  stepTime.textContent = formatTime(remainingSeconds);

  if (remainingSeconds > 0) {
    return;
  }

  if (activeStepIndex < meridianStepButtons.length - 1) {
    setMeridianStep(activeStepIndex + 1, false);
    return;
  }

  stopRoutineTimer();
}

function startRoutineTimer() {
  stopRoutineTimer();
  routineTimer = window.setInterval(tickRoutine, 1000);
}

function resetRoutine() {
  stopRoutineTimer();
  app.classList.remove("routine-active");
  routinePaused = false;
  timerToggleButton?.classList.remove("is-paused");
  setMeridianStep(0, false);
}

navButtons.forEach((button) => {
  button.addEventListener("click", () => {
    if (button.dataset.requireFeedback && button.classList.contains("disabled")) {
      return;
    }

    if (button.dataset.mode) {
      setMode(button.dataset.mode);
    }

    if (button.dataset.planReady) {
      setMode("subscribed");
    }

    let target = button.dataset.target;

    showScreen(target);
  });
});

backButtons.forEach((button) => {
  button.addEventListener("click", goBack);
});

closePaywallButton?.addEventListener("click", closePaywall);

planOptionButtons.forEach((button) => {
  button.addEventListener("click", () => {
    setSelectedPlan(button.dataset.planOption);
  });
});

checkButtons.forEach((button) => {
  button.addEventListener("click", () => {
    const isDone = button.classList.toggle("is-done");
    const labels = {
      en: {
        massageDone: "Massage checked in",
        massage: "Complete check-in",
      },
      zh: {
        massageDone: "按摩已打卡",
        massage: "完成练习",
      },
    };

    button.textContent = isDone
      ? labels[currentLanguage][`${button.dataset.check}Done`]
      : labels[currentLanguage][button.dataset.check];
  });
});

taskButtons.forEach((button) => {
  button.addEventListener("click", () => {
    const target = button.dataset.taskTarget;

    taskButtons.forEach((item) => {
      item.classList.toggle("active", item === button);
    });

    taskPanels.forEach((panel) => {
      panel.classList.toggle("active", panel.dataset.taskPanel === target);
    });
  });
});

choiceGroups.forEach((group) => {
  group.addEventListener("click", (event) => {
    const choice = event.target.closest("button");

    if (!choice || !group.contains(choice)) {
      return;
    }

    group.querySelectorAll("button").forEach((button) => {
      button.classList.remove("active", "featured", "selected");
    });

    if (choice.classList.contains("body-card")) {
      choice.classList.add("featured");
    } else if (choice.parentElement.classList.contains("time-options")) {
      choice.classList.add("selected");
    } else {
      choice.classList.add("active");
    }

    if (choice.dataset.purpose) {
      const [title, copy, massage] = purposeFocus[choice.dataset.purpose] || purposeFocus.default;
      focusTitle.textContent = title;
      focusCopy.textContent = copy;
      massageTarget.textContent = massage;
    } else if (choice.parentElement.classList.contains("feedback-grid")) {
      const [title, copy, massage] = purposeFocus.default;
      focusTitle.textContent = title;
      focusCopy.textContent = copy;
      massageTarget.textContent = massage;
    }
  });
});

aiFillButton?.addEventListener("click", () => {
  aiFillButton.classList.add("is-filled");
  aiFillButton.textContent =
    currentLanguage === "zh"
      ? "最近睡眠偏浅，下午容易疲惫，想先做肝脏调理。"
      : "My sleep has been light, I feel tired in the afternoon, and I want to start with liver care.";
  feedbackSubmitButton.classList.remove("disabled");
});

photoPermissionButton?.addEventListener("click", () => {
  app.classList.add("permission-open");
});

permissionCloseButton?.addEventListener("click", closePermission);

photoButtons.forEach((button) => {
  button.addEventListener("click", () => {
    photoButtons.forEach((item) => item.classList.remove("selected"));
    button.classList.add("selected");
  });
});

confirmPhotoButton?.addEventListener("click", () => {
  app.classList.add("photo-selected");
});

uploadReportButton?.addEventListener("click", () => {
  if (!app.classList.contains("photo-selected")) {
    app.classList.add("permission-open");
    return;
  }

  app.classList.add("baseline-ready");
  showScreen("today");
});

notificationOpenButton?.addEventListener("click", () => {
  app.classList.add("notification-open");
});

notificationAllowButton?.addEventListener("click", () => {
  finishNotificationPrompt(true);
});

notificationLaterButton?.addEventListener("click", () => {
  finishNotificationPrompt(false);
});

profileOpenButton?.addEventListener("click", () => {
  app.classList.add("profile-open");
});

profileCloseButtons.forEach((button) => {
  button.addEventListener("click", closeProfile);
});

deleteAccountOpenButton?.addEventListener("click", () => {
  app.classList.add("delete-account-open");
});

deleteAccountCloseButtons.forEach((button) => {
  button.addEventListener("click", closeDeleteAccount);
});

deleteAccountConfirmButton?.addEventListener("click", () => {
  closeDeleteAccount();
  closeProfile();
});

languageButtons.forEach((button) => {
  button.addEventListener("click", () => {
    setLanguage(button.dataset.language);
  });
});

meridianStepButtons.forEach((button) => {
  button.addEventListener("click", () => {
    const nextIndex = Array.from(meridianStepButtons).indexOf(button);
    setMeridianStep(nextIndex, Boolean(routineTimer));
  });
});

startRoutineButton?.addEventListener("click", () => {
  app.classList.add("routine-active");
  routinePaused = false;
  timerToggleButton?.classList.remove("is-paused");
  setMeridianStep(0, true);
});

timerToggleButton?.addEventListener("click", () => {
  if (!app.classList.contains("routine-active")) {
    return;
  }

  routinePaused = !routinePaused;
  timerToggleButton.classList.toggle("is-paused", routinePaused);
});

completeRoutineButton?.addEventListener("click", () => {
  stopRoutineTimer();
  completeRoutineButton.textContent = currentLanguage === "zh" ? "打卡完成" : "Check-in complete";
  window.setTimeout(() => {
    completeRoutineButton.textContent = currentLanguage === "zh" ? "完成打卡" : "Complete check-in";
    showScreen("today");
  }, 450);
});
