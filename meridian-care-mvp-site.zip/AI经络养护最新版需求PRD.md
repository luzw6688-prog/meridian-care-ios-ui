# AI 经络养护 最新版需求 PRD

版本：V1.0.0
更新时间：2026-06-02

## 1. 产品定位

AI 经络养护是一款面向西方用户的轻量自助按摩打卡 App。用户通过 Apple 登录后先完成计划定制，在 AI 准备生成方案时进入订阅付费墙；用户可关闭订阅墙进入未订阅浏览态，也可订阅后进入每日打卡流程。

产品核心不做医疗诊断，不承诺疾病治疗结果，重点提供日常自助按摩、打卡习惯和 AI 个性化计划。

## 2. 核心用户

- 希望通过简单按摩改善睡眠、疲劳、压力、肩颈紧绷等状态的用户。
- 偏好短时、低门槛、可在家完成的 self-care 用户。
- 愿意为 AI 个性化计划、步骤引导和周期复盘付费的用户。

## 3. MVP 核心目标

- 用 3 步以内完成首次计划定制。
- 用订阅墙承接 AI 计划生成节点。
- 用“首页 + 打卡”两个底部模块保持产品结构极简。
- 用手部经络点、步骤高亮、倒计时和暂停能力完成每日打卡。
- 用周期完成状态引导用户继续原计划或进入 AI 进阶计划。

## 4. 用户主流程

1. 用户进入 App。
2. 使用 Apple 登录。
3. 进入计划定制流程。
4. 选择最想改善的目标。
5. 确认养生目标、建议按摩部位和每日投入时间。
6. 可补充当前身体状态，也可跳过。
7. 点击提交或跳过后进入订阅付费墙。
8. 用户可关闭订阅墙进入未订阅浏览态。
9. 用户订阅后生成 AI 打卡计划。
10. 进入 App 前出现通知授权提示，可允许或稍后设置。
11. 进入首页，查看今日计划、本周小结、周期完成状态。
12. 进入打卡页，点击 Start check-in 开始。
13. 开始后，今日打卡卡片整体消失，由按摩引导流程替代。
14. 用户按步骤完成打卡。

## 5. 信息架构

底部导航只保留两个模块：

- 首页
- 打卡

暂时隐藏：

- 养生内容模块
- 调理趋势模块
- 体检报告上传与 AI 指标分析

## 6. 登录与计划定制

登录方式：

- 使用 Apple 登录。

计划定制步骤：

第一步：选择改善目标。

- Sleep & Relaxation
- Fatigue Relief
- Digestive Care
- Energy & Circulation
- Liver Care
- Weight & Fat Loss

第二步：确认计划设置。

- 展示用户选择的养生目标。
- 展示建议按摩部位。
- 选择每日投入时间：5 分钟、10 分钟、15 分钟。
- 默认 10 分钟。

第三步：AI 补充反馈。

- 用户可输入睡眠、压力、酸痛、疲劳等状态。
- 用户也可直接跳过。
- 若选择提交反馈，输入为空时不能提交。

## 7. 订阅付费墙

触发时机：

- 首次计划定制完成，AI 准备生成方案时弹出。
- 未订阅状态下点击首页或打卡页订阅引导时弹出。
- 设置中点击订阅情况时弹出。

付费墙顶部：

- 使用 Close，不使用 Back。
- 用户关闭后进入未订阅浏览态。

订阅权益展示：

- 顶部会员标题区域保持独立。
- 中间权益视觉上合并为一个整体卡片。
- 卡片内保留三条权益，每条前面有小图标：
  - Personalized massage plan
  - Guided meridian massage
  - Progress insights

订阅方案：

- Monthly：$9.90/month。
- Annual：突出 $4.16/month。
- Annual 弱化展示 $49.90 billed yearly。
- Annual 提供 3-day free trial。
- 月订阅和年订阅可点击切换选中态。
- 切换后按钮上方说明文案同步变化。

订阅说明位置：

- 放在开通会员按钮上方。
- 年订阅说明：Annual plan includes a 3-day free trial, then renews automatically.
- 月订阅说明：Monthly plan renews automatically at $9.90/month.
- 不展示 Cancel anytime。

订阅按钮：

- 年订阅选中时：Start 3-day free trial。
- 中文：立即免费体验 3 天。
- 月订阅选中时：Start membership。
- 中文：开通会员。

付费墙底部链接：

- Restore Purchase · Terms · Privacy Policy

## 8. 未订阅浏览态

首页未订阅状态：

- 展示引导卡片。
- 核心文案：Subscribe to start daily check-ins。
- 中文：订阅 App，立即开始每日打卡。
- 点击按钮后重新弹出订阅付费墙。

打卡页未订阅状态：

- 展示缺省说明。
- 告知手部引导、倒计时、经络点高亮需订阅后解锁。
- 提供订阅按钮。

无数据区域：

- 使用自然缺省描述，避免空白页。

## 9. 首页

订阅后首页展示：

- 个人计划卡片。
- 今日练习入口。
- 本周打卡小结。
- 周期完成状态。
- 右上角头像进入设置。
- 右上角提供重新定制计划入口。

周期完成状态：

- 提示用户打卡计划已完美实施。
- 用户可继续原计划打卡。
- 用户可进入进阶打卡计划。

进阶打卡计划：

- 先进入上一周期复盘页。
- 例如上一周期目标为睡眠放松时，询问：
  - 睡眠质量是否改善？
  - 是明显改善、略有改善，还是暂无明显变化？
  - 入睡是否更快？
  - 夜间醒来是否减少？
  - 醒后精神是否更好？
- 用户提交复盘后，不再重新选择时间。
- 不再进入 AI 对话补充页。
- AI 直接生成进阶计划并进入打卡模块。

## 10. 打卡模块

进入打卡页后：

- 初始只展示今日打卡开始卡片。
- 核心按钮：Start check-in。
- 用户点击后，整个今日打卡开始区域消失。
- 页面切换为按摩引导流程。

按摩引导流程：

- 展示拟人化手部示意。
- 展示手部经络点。
- 当前步骤对应点位高亮。
- 展示步骤名称、说明和倒计时。
- 倒计时默认自动运行。
- 点击倒计时圆环可暂停或继续。
- 每一步倒计时时长由计划配置。
- 用户可点击步骤切换按摩部位。
- 完成后点击 Complete check-in。

## 11. 设置

设置入口：

- 首页右上角头像。

设置内容：

- 用户信息
- 订阅情况
- 多语言切换
- 关于我们：V1.0.0
- Log Out
- Restore Purchase
- Terms
- Privacy Policy
- Delete Account

设置底部链接展示：

- 第一行：Restore Purchase · Delete Account
- 第二行：Terms · Privacy Policy

账号注销：

- Delete Account 不使用红色字体凸显。
- 点击后出现二次确认弹窗。
- 弹窗说明将永久删除账号、个人计划、打卡记录和偏好设置。
- 提醒有效订阅仍需通过 App Store 管理。
- 确认注销后返回登录页。
- 只有确认注销弹窗中的危险按钮使用红色。

## 12. 多语言

支持：

- English
- 中文

要求：

- 切换语言不重置当前页面。
- 不重置订阅状态。
- 不重置当前选择、打卡状态和计划状态。
- 中文文案不直译英文，优先符合中文 App 的自然表达。

## 13. 返回规则

所有 Back / Cancel 均返回上一级界面。

要求：

- 不固定跳转到某个页面。
- 从订阅页、计划页、进阶复盘页、上传页、相册页等返回时，都按来源返回。
- 带返回按钮的页面，返回按钮单独一行，标题另起一行。

## 14. 暂缓功能

当前 MVP 暂不包含：

- 泡茶养生打卡。
- 茶饮配方与泡茶步骤。
- 养生内容模块。
- 调理趋势模块。
- 体检报告上传正式能力。
- 医疗诊断、处方建议或疾病治疗承诺。

## 15. 数据埋点需求

### 15.1 埋点目标

埋点用于验证以下核心问题：

- 用户是否能顺利完成首次计划定制。
- 订阅墙在计划生成节点的转化表现。
- 用户关闭订阅墙后的浏览和再次触发订阅情况。
- 每日打卡开始、暂停、完成的行为路径。
- 周期完成后，用户更倾向继续原计划还是进入进阶计划。
- 多语言、设置、账号注销等辅助功能使用情况。

### 15.2 公共事件参数

所有事件建议携带以下公共参数：

- user_id：用户匿名 ID。
- session_id：当前会话 ID。
- app_version：当前版本，例如 V1.0.0。
- language：当前语言，en 或 zh。
- subscription_status：subscribed / unsubscribed / trial_active。
- entry_source：事件来源页面或入口。
- timestamp：事件发生时间。
- platform：iOS。

### 15.3 核心事件列表

启动与登录：

- app_open：用户打开 App。
- apple_sign_in_click：点击 Apple 登录。
- apple_sign_in_success：Apple 登录成功。
- apple_sign_in_fail：Apple 登录失败。

计划定制：

- plan_setup_start：进入计划定制。
- plan_goal_select：选择改善目标。
  - 参数：goal。
- plan_time_select：选择每日投入时间。
  - 参数：duration_minutes。
- ai_feedback_input_click：点击 AI 补充输入框。
- ai_feedback_submit：提交 AI 反馈。
  - 参数：has_text、text_length。
- ai_feedback_skip：跳过 AI 反馈。

订阅付费墙：

- paywall_show：订阅墙曝光。
  - 参数：trigger_source，例如 first_plan_generate、home_locked、checkin_locked、settings_subscription。
- paywall_close：关闭订阅墙。
- subscription_plan_select：选择订阅方案。
  - 参数：plan_type，monthly / annual。
- subscription_cta_click：点击订阅主按钮。
  - 参数：plan_type、cta_text。
- subscription_success：订阅成功。
  - 参数：plan_type、trial_started。
- subscription_fail：订阅失败。
  - 参数：plan_type、fail_reason。
- restore_purchase_click：点击恢复购买。
- terms_click：点击 Terms。
- privacy_policy_click：点击 Privacy Policy。

通知授权：

- notification_permission_show：通知授权弹窗曝光。
- notification_allow_click：点击允许通知。
- notification_later_click：点击稍后设置。

首页：

- home_view：进入首页。
- home_locked_cta_click：未订阅首页点击订阅引导。
- retune_plan_click：点击重新定制计划。
- today_routine_click：点击今日练习入口。
- cycle_complete_show：周期完成卡片曝光。
- continue_original_plan_click：点击继续原计划打卡。
- advanced_plan_click：点击开始进阶打卡计划。

进阶计划复盘：

- advanced_review_show：进入进阶复盘页。
- advanced_review_answer_select：选择复盘答案。
  - 参数：question_id、answer_value。
- advanced_plan_generate_click：点击生成并进入打卡。

打卡模块：

- checkin_view：进入打卡页。
- checkin_locked_cta_click：未订阅打卡页点击订阅引导。
- checkin_start_click：点击 Start check-in。
- massage_step_view：进入某一步按摩。
  - 参数：step_index、step_name、duration_seconds。
- massage_step_click：手动切换按摩步骤。
  - 参数：from_step、to_step。
- timer_pause_click：暂停倒计时。
  - 参数：step_index、remaining_seconds。
- timer_resume_click：继续倒计时。
  - 参数：step_index、remaining_seconds。
- checkin_complete_click：点击完成打卡。
- checkin_complete_success：打卡完成成功。
  - 参数：total_duration_seconds、completed_steps。

设置：

- settings_open：打开设置。
- language_change：切换语言。
  - 参数：from_language、to_language。
- subscription_manage_click：点击订阅情况。
- logout_click：点击退出登录。
- delete_account_click：点击账号注销入口。
- delete_account_cancel：取消账号注销。
- delete_account_confirm：确认账号注销。

### 15.4 关键转化漏斗

首次计划生成漏斗：

app_open → apple_sign_in_success → plan_setup_start → plan_goal_select → ai_feedback_submit / ai_feedback_skip → paywall_show → subscription_cta_click → subscription_success → plan_result_view → home_view

未订阅转化漏斗：

paywall_close → home_view → home_locked_cta_click / checkin_locked_cta_click → paywall_show → subscription_cta_click → subscription_success

每日打卡漏斗：

home_view → today_routine_click → checkin_view → checkin_start_click → checkin_complete_click → checkin_complete_success

进阶计划漏斗：

cycle_complete_show → advanced_plan_click → advanced_review_show → advanced_plan_generate_click → checkin_view → checkin_complete_success

### 15.5 关键指标

- 首次计划完成率。
- 订阅墙曝光到订阅点击转化率。
- 年订阅选择率。
- 年订阅 3 天试用点击率。
- 关闭订阅墙后的二次付费墙触发率。
- 打卡开始率。
- 打卡完成率。
- 倒计时暂停率。
- 周期完成后的进阶计划点击率。
- 进阶计划生成后打卡完成率。
- 中文/英文切换比例。
- 账号注销点击率与确认注销率。

### 15.6 埋点注意事项

- 不采集用户 AI 输入的明文内容，只记录是否输入和字数长度。
- 健康、睡眠、压力等敏感反馈只做枚举化统计，不上传原文。
- 订阅失败原因应使用标准错误码，不记录支付账号信息。
- 所有埋点需符合隐私政策说明。
- 如接入第三方分析工具，应在隐私政策中披露。

## 16. ASO 优化建议

### 16.1 元数据限制参考

根据 Apple App Store Connect 规则：

- App 名称需为 2-30 个字符。
- Subtitle 不超过 30 个字符。
- Keywords 字段最多 100 bytes。
- Description 最多 4000 字符。
- App 可通过名称、副标题、关键词和公司名称被搜索。

### 16.2 命名策略

根据最新关键词分析，ASO 主轴调整为 meridian 优先，acupressure 第二，TCM 第三。App 名称应优先承接 meridian 搜索趋势，同时保留自然、可信、非医疗化的 wellness 气质。

推荐主名称：

1. Meridian Care
2. Meridian Massage
3. Meridian Self Massage
4. Meridian Acupressure
5. Meridian Reset

最推荐名称：

- Meridian Care

理由：

- 直接承接 meridian 搜索趋势。
- 名称短、清晰，适合长期品牌化。
- 不使用 cure、therapy、treatment 等医疗承诺词。
- 可通过副标题和关键词继续覆盖 acupressure、self massage、TCM 等方向。

如果希望标题更直接覆盖按摩搜索：

- Meridian Massage

### 16.3 App Store 标题候选

英文标题候选：

1. Meridian Care
2. Meridian Massage
3. Meridian Self Massage
4. Meridian Acupressure
5. Meridian Care: Acupressure

推荐标题：

- Meridian Care

搜索导向更强的备选：

- Meridian Massage
- Meridian Acupressure

不建议作为首选：

- TCM Meridian Care

原因：TCM 当前作为第三优先级关键词，更适合放入关键词字段或描述中，不建议占据 App 名称核心位置。

### 16.4 Subtitle 候选

英文 Subtitle 候选：

1. Guided acupressure plan
2. Daily self-massage guide
3. AI meridian massage plan
4. Gentle meridian check-ins
5. TCM self-care routines

推荐 Subtitle：

- Guided acupressure plan

备选：

- Daily self-massage guide
- AI meridian massage plan

策略说明：

- App 名称使用 Meridian Care 时，Subtitle 可优先放 acupressure，覆盖第二搜索方向。
- TCM 放在副标题备选或关键词中，避免标题整体过度中医化。

### 16.5 关键词策略

关键词优先级：

1. meridian
2. acupressure
3. TCM
4. self massage
5. sleep / stress relief / relaxation 等场景词

关键词应避免重复 App 名称中的词，避免竞品名和医疗承诺词。

英文关键词方向：

- meridian
- meridian massage
- acupressure
- self massage
- hand massage
- wellness
- sleep
- stress relief
- relaxation
- habit
- check in
- guided routine
- AI plan
- TCM

关键词组合示例：

acupressure,self massage,hand massage,sleep,stress relief,relaxation,wellness,habit,check in,TCM

如果 App 名称未使用 meridian，可加入：

meridian,acupressure,self massage,hand massage,sleep,stress relief,relaxation,wellness,TCM

中文关键词方向：

- 经络按摩
- 经络养护
- 穴位按摩
- 自助按摩
- 手部按摩
- 养生打卡
- AI 计划
- 睡眠放松
- 肩颈放松
- TCM
- 中医按摩

### 16.6 App 描述建议

英文短描述方向：

Meridian Care helps you build a gentle daily self-massage habit with AI-personalized plans, guided acupressure check-ins, highlighted meridian points, and simple progress summaries.

中文说明方向：

Meridian Care 是一款轻量自助按摩打卡 App。你可以根据睡眠、疲劳、压力、肩颈紧绷等目标生成 AI 个性化计划，并通过手部经络点、步骤高亮和倒计时完成每日打卡。

### 16.7 截图文案建议

截图 1：

- AI builds your meridian plan
- AI 为你生成每日经络按摩计划

截图 2：

- Start your daily check-in
- 开始每日打卡

截图 3：

- Follow highlighted acupressure points
- 跟随高亮穴位点按摩

截图 4：

- Pause, continue, complete
- 可暂停、可继续、可完成

截图 5：

- Review your cycle, advance your plan
- 复盘周期，进入进阶计划

### 16.8 订阅页转化文案建议

年订阅主按钮：

- Start 3-day free trial
- 立即免费体验 3 天

月订阅主按钮：

- Start membership
- 开通会员

未订阅首页引导：

- Subscribe to start daily check-ins
- 订阅 App，立即开始每日打卡

### 16.9 ASO 注意事项

- 当前策略：meridian 主导，acupressure 补强，TCM 辅助。
- 不使用 cure、treat disease、medical therapy 等医疗承诺词。
- 不在关键词中重复 App 名称已有词。
- 不使用竞品名。
- 截图首屏优先展示“AI 计划 + 每日打卡”的核心价值。
- 英文文案保持短句，减少文化理解门槛。
- 如果后续 TCM 搜索趋势回升，可将 TCM 放入副标题或关键词中测试，不建议优先替换掉 meridian 主品牌。
